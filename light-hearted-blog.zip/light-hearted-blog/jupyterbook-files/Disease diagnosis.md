# Cardiovascular disease diagnose 
---

## Cardiovascular system and diseases

The human heart works relentlessly from before birth to death. It beats about 100,000
times per a day and the blood is pumped to all parts of the body through the vessels or
arteries with every single beat. The heart and blood vessels, the parts of the cardiovascular
system, are important because they bring oxygen, nutrients and other good things to every
cell in the body as well as taking away carbon dioxide and waste.�

The disorder or anomaly in this system is called a cardiovascular disease. There are many
types of cardiovascular diseases such as heart valve disease, heart stroke, rheumatic heart
disease, venous thrombosis etc.�Cardiovascular diseases kill an estimated 17 million people worldwide 
each year. Majority of these are due to heart attacks and strokes. Physical inactivity and unhealthy 
diet leading to obesity are other important risk factors which increase individual risks 
to cardiovascular diseases.

Cardiovascular diseases are diagnosed in the US using a variety of methods, including
physical exams, laboratory tests, and imaging studies. Medical history and physical
examination: The doctor will ask about symptoms and risk factors for cardiovascular
diseases and perform a physical examination to check for signs of cardiovascular diseases,
such as a heart murmur or peripheral artery disease.


## How to diagnose a cardiovascular disease

�Some common diagnostic tests used to evaluate cardiovascular diseases include:

* Blood tests: These can check for high levels of cholesterol, triglycerides, and other
markers of heart disease.

* Electrocardiogram (ECG or EKG): This test records the electrical activity of the heart and
can detect abnormal rhythms or heart damage.

* Echocardiogram: This test uses sound waves to create a moving image of the heart,
allowing doctors to evaluate the heart's structure and function.

* Cardiac CT or MRI: These imaging tests can provide detailed pictures of the heart and
blood vessels, allowing doctors to identify blockages or other issues.

* Stress tests: These tests assess how the heart functions during physical activity and can
help identify problems that may not be evident at rest.

* Coronary angiography: This test uses X-ray imaging to look at the blood vessels that
supply the heart and can identify blockages or narrowed vessels.

A combination of these diagnostic tests may be used to confirm a diagnosis of CVD and
determine the appropriate course of treatment.
�
