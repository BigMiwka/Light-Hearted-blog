# Light-Hearted Blog File

This webpage contains the documents constituting the blog files which will be needed to ask for ethics approval.

At your left you will see the titles of the various documents. Click on them to navigate to the desired document.
