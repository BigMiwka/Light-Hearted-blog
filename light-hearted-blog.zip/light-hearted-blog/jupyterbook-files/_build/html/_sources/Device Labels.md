# Device Labels

## Manufacturer's name and Organization's address
-Lucrezia Cester
-Lucrezia.Cester@gstt.nhs.uk
-Westminster Bridge Road London, SE1 7EH, England, Guy's and St Thomas Hospital Trust.

## Device Indentification Details
The device consists of:
-the main box with enclosed laseer plus camera
-usb to connect device to computer
-software

## Clinical Investigation Requirements
At this stage the device can only be used for clinical investigation.

## Holding conditions
The device is fragile, so don't shake it and don't drop it.

## Operating Instructions
-attach one end of the cable into the device and the other to the computer
-launch software
-follow instructions provided on the software webpage for how to acquire data

## Warnings
Do not place laser device pointed close to your face while pointing in your eyes. Only use the device for its inteded purpose.
