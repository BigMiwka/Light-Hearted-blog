#Device Purpose
The device needs to acquire the signal for heart valve sounds and has been designed and manufactured to do so.


#Side Effects
If the laser is pointed in the eye of the patient for a prolonged period of time, damage to the eye may occur. The device should only be used for its intended 
purpose and according to specifications.


#Installation Instructions
The device needs to be connected to the computer. The laser needs to be turned on via the switch.
The device is now ready to use. 

#Re-use Instructions
The device is reusable. Since it does not come in contact with the patient or touched, the switch just needs to be cleaned with a wipe when deemed necessary as this is the only part 
of the device whihc will be routinely touched.



